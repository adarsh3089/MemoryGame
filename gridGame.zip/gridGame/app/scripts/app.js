'use strict';

/**
 * @ngdoc overview
 * @name gridGameApp
 * @description
 * # gridGameApp
 *
 * Main module of the application.
 */
angular
  .module('gridGameApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl',
        controllerAs: 'main'
      })
      .otherwise({
        redirectTo: '/'
      });
  });

  