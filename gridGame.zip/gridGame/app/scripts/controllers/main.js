'use strict';

/**
 * @ngdoc function
 * @name gridGameApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the gridGameApp
 */
angular.module('gridGameApp')
  .controller('MainCtrl',["$scope","$timeout","$window", function ($scope,$timeout,$window) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
    ];
 
	  
 //Shuffling the cards in the deck    
   var shuffleArray = function(array) {
  
      var m = array.length, t, i;
      while (m) {
             // Pick a remaining element…
			 i = Math.floor(Math.random() * m--);

			 // And swap it with the current element.
			 t = array[m];
			 array[m] = array[i];
			 array[i] = t;
			 }
        boardDeck(array);
        return array;
    };
    
   var boardDeck = function(array) {
      
      for(var i = 0;i<array.length;i++){
          
         array[i] = {
             card : array[i]
         };
          
      }
      return array;
      
   };
 
//Creating the new cardDeck
  function resetGrid() {
        $scope.score = 0;
        $scope.cardArray= [];
        for(var m=0;m<2;m++){
        for(var i=1;i<=8;i++){
              $scope.cardArray.push(i);
          }
    }
    shuffleArray($scope.cardArray);
      
  }
	  
  resetGrid();
	  
// For flippping the card on click
   var clickCount = 0;
   var cardFlipped = 0;
   
   $scope.flipCard = function(value,$index){
       
      var current = $scope.cardArray[$index];
      if(current.isflipped){
          return;
      }
      
      current.isflipped = false ;
      if(clickCount < 2) {
          
          current.isflipped = true;
      //Storing the first flip card index
          if(clickCount === 0 ){
               clickCount++;
               $scope.lastCard = $index;
              
              
          } else if(clickCount === 1) {
               clickCount++;
			//Matching the first and 2nd card value
               if($scope.cardArray[$scope.lastCard].card === $scope.cardArray[$index].card){
                    $scope.score += 10; 
                    $scope.lastCard = "";
                    clickCount = 0;
                    cardFlipped += 2;
                //Checking if all cards are flipped then resetting the deck  
                   if(cardFlipped === $scope.cardArray.length){
                       
                     $timeout(function () 
                       {
                           $window.alert("Congrats....Winner");
                           resetGrid();
                           cardFlipped = 0;
                       
                       }, 1000);
                      
                   }
                   
               } else {
                // Flipping back the cards if its not matched 
                    $timeout(function () 
                       {
                         $scope.cardArray[$scope.lastCard].isflipped = false; 
                         current.isflipped = false;
                         $scope.lastCard = "";
                         clickCount = 0;
                       
                       }, 1000);
    
                  }
              
          }
          
      }
  };
  
     

    
  }]);
